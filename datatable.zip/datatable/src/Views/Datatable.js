import React,{useState,useEffect,useReducer} from 'react'
import { Form, Button, Container, Row, Col } from 'react-bootstrap';
import BootstrapTable from 'react-bootstrap-table-next';
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';

  const initialState=10
  const reducer = (state,action)=>{
      switch (action) {
          case 'INCREMENT':
          return state + 10
         case 'DECREMENT':
          return state - 10
          default:
              return state;
      }
  }
export const Datatable=()=>{

  const   [values,setValues]=useState([]);

  const [state, dispatch] = useReducer(reducer, initialState)



      const columns = [{
      dataField: 'id',
      text: 'Id',

    }, {
      dataField: 'name',
      text: 'Name'
    }, {
      dataField: 'tagline',
      text: 'tagline'
    },  {
      dataField: 'first_brewed',
      text: 'first_brewed'
    },  {
      dataField: 'description',
      text: 'description',

    }, {
      dataField: 'image_url',
      text: 'image_url',

    }];
    useEffect(()=>{
        let url='https://api.punkapi.com/v2/beers?page=1&per_page='+state
fetch(url)
.then(response => response.json())
.then(json => setValues(json))
    })
    return(
        <>
<br/>

   &nbsp;&nbsp;   <Button onClick={()=>dispatch("DECREMENT")}>  previous </Button> &nbsp;
<Button onClick={()=>dispatch("INCREMENT")}>  Next </Button>&nbsp;
<br/>
{state}
  <BootstrapTable
            keyField='id'
            data={ values }
            bordered
            bootstrap4
            columns={ columns }
              />

        </>
    )
}