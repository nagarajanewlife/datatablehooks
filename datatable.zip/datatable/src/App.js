
import './App.css';
import {Datatable} from './Views/Datatable'
function App() {
  return (
    <Datatable/>
  );
}

export default App;
